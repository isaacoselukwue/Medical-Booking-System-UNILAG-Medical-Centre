
<div class="alert alert-info"><strong>About US</strong></div>
<div class="about">
   

    <p>
         Dr. Mrs Ramota Apampa,is the Director, Medical Service, University of Lagos, Akoka, Nigeria.
            The services offered are child health,maternal health, men's health, wellness, weight loss, wound care,
            HIV care,General medical care,Elderly and aged care,emergencies,house calls,tourist calls and 
            workman's compensation cases.
            The general practice is equipped for sonar,ECG, lung function, cuattery, flouroscopy X-Ray and minor surgical procedures.
            House calls, workplace calls, calls to hotels and guesthouses are also available.
       
    </p>

</div>
