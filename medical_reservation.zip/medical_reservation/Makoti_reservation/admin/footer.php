<div class="container">   
   <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
        <p><a>Copyright 2018. All Rights reserved</a></p>
      </div>
      </div>
    </footer>
</div>
</body>
</html>