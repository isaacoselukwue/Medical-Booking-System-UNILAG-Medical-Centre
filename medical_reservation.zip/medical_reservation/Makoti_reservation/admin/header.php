<!DOCTYPE html>
<html>
    <head>
        <title>UNILAG MEDICAL CENTRE</title>
        <link href="../img/log.png" rel="icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Bootstrap -->
        <link href="../css/bootstrap.css" rel="stylesheet" media="screen">
        <link href="../css/bootstrap-responsive.css" rel="stylesheet" media="screen">
        <link href="../css/docs.css" rel="stylesheet" media="screen">
        <link href="../css/font-awesome.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" type="text/css" href="../css/DT_bootstrap.css">
        <!-- js -->			
        <script src="../js/jquery-1.7.2.min.js"></script>
        <script src="../js/bootstrap.js"></script>			
        <script type="text/javascript" charset="utf-8" language="javascript" src="../js/jquery.dataTables.js"></script>
        <script type="text/javascript" charset="utf-8" language="javascript" src="../js/DT_bootstrap.js"></script>

        <!--sa calendar-->	
        <script type="text/javascript" src="../js/datepicker.js"></script>
        <link href="../css/datepicker.css" rel="stylesheet" type="text/css" />



    </head>
    <?php include('dbcon.php'); ?>
    <body>