
<div class="alert alert-info"><strong>Contact US</strong></div>
<div class="about">
    <p>
        New Access Road
        University of Lagos
        Lagos
        +234 1 280 2439

    </p>
</div>
