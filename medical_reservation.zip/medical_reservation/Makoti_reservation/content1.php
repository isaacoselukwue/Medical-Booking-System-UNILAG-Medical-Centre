<div class="text_content">
    
    <p> The three conerstones of our business and our commitment to our patients are LIFE, HEALTH AND CARE.
        LIFE summarises our philosophy of protecting our patient's wellbeing and quality of life.
        HEALTH is our clinical excellence in world-class facilities and CARE is the human touch 
        of providing quality services,respect and emphathy for those entrusted to our care. 
    </p>
</div>