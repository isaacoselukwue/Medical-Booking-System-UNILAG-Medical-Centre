<div class="testimonial">	
    <div class="caption_index_2">DOCTOR PROFILE</div>
    <div class="testimonial_div">
        <p>
            Dr O. A. Abosede is a  family doctor at the University of Lagos Medical Centre, Akoka, Lagos.
            The services offered are child health,maternal health, men's health, wellness, weight loss, wound care,
            HIV care,General medical care,Elderly and aged care,emergencies,house calls,tourist calls and 
            workman's compensation cases.
            The centre is equipped for sonar,ECG, lung function, cuattery, flouroscopy X-Ray and minor surgical procedures.
            The doctors do house calls, workplace calls, calls to hotels and guesthouses.
        </p>
    </div>
    <div class="caption_index_2">TESTIMONIAL</div>
    <div class="testimonial_div1">
        <p>
            I was delighted with the treatment. Despite me being a somewhat difficult patient the nurses and doctors were really gentle, patient and understanding.
            The treatment was explained precisely to me and the price was free being a member of the University Community.
            The transformation to my life in general has been amazing. 
            I am extremely happy with the quality of the treatment.
        </p>
    </div>
</div>
<div class="contact_us">
    <div class="caption_index_2">Qualifications</div>
    <p>MBBS</p>
    <p>M. Ed</p>
    <div class="caption_index_2">Memberships & Associations</div>
    <p>NMA - Member</p>
    <div class="caption_index_2">Office Hours</div>
    <p>Monday - Friday (9:00 to 18:00 )</p>
    <p>Saturday(half day)</p>
    <p>Sunday(half day)</p>
    <p>New Access Road</p>
	<p>University of Lagos, Lagos.</p>

</div>
